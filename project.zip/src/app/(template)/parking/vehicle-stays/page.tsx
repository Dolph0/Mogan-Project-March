import Banner from "@/components/Parking/VehicleStays/Banner";
import Content from "@/components/Parking/VehicleStays/Content";
export default function VehicleStays() {
  return (
    <main>
      <Banner />
      <Content />
    </main>
  );
}
