import Banner from "@/components/Parking/Driving/Banner";
import Playlist from "@/components/Parking/Driving/Playlist";
export default function Driving() {
  return (
    <main>
      <Banner />
      <Playlist />
    </main>
  );
}
