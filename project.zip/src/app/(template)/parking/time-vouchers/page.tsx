import Banner from "@/components/Parking/Vouchers/Banner";
import Demo from "@/components/Parking/Vouchers/Demo";
import Info from "@/components/Parking/Vouchers/Info";
export default function TimeVouchers() {
  return (
    <main>
      <Banner />
      <Info />
      <Demo />
    </main>
  );
}
